function [data, std_mean] = getData( mode)
    if strcmp(mode, 'all')
        files = dir('../../data/*.txt');
    else
        files = dir('../../data/*WA.txt');
    end
    
    num_features = 6;
    num_y_stacks = 1;
    num_x_stacks = 6;
    samples_per_file = 365*24/4 - num_x_stacks - num_y_stacks + 1;
    
    dataX = zeros(samples_per_file, num_x_stacks, num_features);
    dataY = zeros(samples_per_file, num_y_stacks, num_features);
    
    for f=1:max(size(files))
        [raw_data, std_mean] = parseData(files(f).name);
        
        for row = 1:samples_per_file
            for stack = 1:num_x_stacks
                dataX((f-1) * samples_per_file + row, stack, :) = raw_data(row + stack - 1, :);
            end
            dataY((f-1) * samples_per_file + row, num_y_stacks, :) = raw_data(row + num_x_stacks, :);
        end
    end
    
    num_rows = size(dataX,1);
    
    i_perm = randperm(num_rows);
    
    data = struct;
    data.trainX = dataX(i_perm(1 : floor(num_rows / 2)), :, :);
    data.trainY = dataY(i_perm(1 : floor(num_rows / 2)), :, :);
    data.validateX = dataX(i_perm(floor(num_rows / 2) + 1 : floor(3 * num_rows / 4)), :, :);
    data.validateY = dataY(i_perm(floor(num_rows / 2) + 1 : floor(3 * num_rows / 4)), :, :);
    data.testX = dataX(i_perm(floor(3 * num_rows / 4) + 1 : num_rows), :, :);
    data.testY = dataY(i_perm(floor(3 * num_rows / 4) + 1 : num_rows), :, :);
end